import React from 'react';
import { 
  Code2, 
  ShoppingBag, 
  Smartphone, 
  Settings, 
  Search, 
  Clock, 
  ChevronRight,
  Star,
  Mail,
  Github,
  Linkedin,
  Twitter,
  Check
} from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-sm z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Code2 className="h-8 w-8 text-red-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">SimpleDotWeb</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#about" className="text-gray-600 hover:text-red-600 transition-colors">About</a>
              <a href="#services" className="text-gray-600 hover:text-red-600 transition-colors">Services</a>
              <a href="#portfolio" className="text-gray-600 hover:text-red-600 transition-colors">Portfolio</a>
              <a href="#pricing" className="text-gray-600 hover:text-red-600 transition-colors">Pricing</a>
              <a href="#contact" className="text-gray-600 hover:text-red-600 transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-24 bg-gradient-to-br from-red-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Your Dream Website, Made Simple.
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Affordable, custom websites designed for small businesses, creators, and entrepreneurs
              – by a passionate solo developer.
            </p>
            <div className="flex justify-center gap-4">
              <button className="bg-red-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-red-700 transition-colors">
                Get Your Free Consultation
              </button>
              <button className="border border-gray-300 text-gray-700 px-8 py-3 rounded-lg font-medium hover:border-red-600 hover:text-red-600 transition-colors">
                See My Work
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8">Meet Your Developer</h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              I'm Jana, the face behind SimpleDotWeb. As a one-person website-building service, I'm dedicated to creating affordable, custom websites that are as unique as your business. Whether you're a small business owner, a creative professional, or an entrepreneur with a big idea, I'm here to make your online presence simple, stylish, and effective.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">Services I Offer</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: <Code2 className="h-8 w-8" />, title: 'Custom Website Design', description: 'Beautifully crafted websites tailored to your brand.' },
              { icon: <Smartphone className="h-8 w-8" />, title: 'Responsive Design', description: 'Websites that look great on all devices.' },
              { icon: <ShoppingBag className="h-8 w-8" />, title: 'E-Commerce Solutions', description: 'Sell your products online with ease.' },
              { icon: <Settings className="h-8 w-8" />, title: 'Website Maintenance', description: 'Keep your site running smoothly.' },
              { icon: <Search className="h-8 w-8" />, title: 'SEO Optimization', description: 'Get found by your target audience.' },
              { icon: <Clock className="h-8 w-8" />, title: 'Fast Turnaround', description: 'Quick delivery without compromising quality.' },
            ].map((service, index) => (
              <div key={index} className="p-6 border border-gray-100 rounded-xl hover:shadow-lg transition-shadow bg-white">
                <div className="text-red-600 mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">Simple, Transparent Pricing</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Basic",
                price: "999",
                description: "Perfect for small businesses just getting started",
                features: [
                  "3 Pages",
                  "Mobile Responsive",
                  "Contact Form",
                  "Basic SEO",
                  "2 Rounds of Revisions",
                  "2 Weeks Delivery"
                ]
              },
              {
                name: "Professional",
                price: "1,999",
                description: "Ideal for growing businesses",
                features: [
                  "7 Pages",
                  "Mobile Responsive",
                  "Advanced Contact Forms",
                  "Advanced SEO",
                  "3 Rounds of Revisions",
                  "3 Weeks Delivery",
                  "Basic Analytics",
                  "Social Media Integration"
                ]
              },
              {
                name: "E-Commerce",
                price: "3,999",
                description: "For businesses ready to sell online",
                features: [
                  "10 Pages",
                  "Full E-Commerce Setup",
                  "Product Management",
                  "Payment Integration",
                  "Inventory System",
                  "Advanced Analytics",
                  "Premium Support",
                  "4 Weeks Delivery"
                ]
              }
            ].map((plan, index) => (
              <div key={index} className="p-8 border border-gray-100 rounded-xl hover:shadow-lg transition-shadow bg-white">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-red-600">AED {plan.price}</span>
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-gray-600">
                      <Check className="h-5 w-5 text-red-600 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <a 
                  href={`https://wa.me/YOUR_PHONE_NUMBER?text=I'm interested in the ${plan.name} package for AED ${plan.price}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block w-full bg-red-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-red-700 transition-colors text-center"
                >
                  Get Started
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">Recent Projects</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
                title: "E-Commerce Website",
                description: "Modern online store with seamless checkout"
              },
              {
                image: "https://images.unsplash.com/photo-1522542550221-31fd19575a2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
                title: "Portfolio Site",
                description: "Clean and minimal portfolio for a photographer"
              },
              {
                image: "https://images.unsplash.com/photo-1556155092-490a1ba16284?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
                title: "Business Website",
                description: "Professional site for a local business"
              }
            ].map((project, index) => (
              <div key={index} className="group relative overflow-hidden rounded-xl">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/0 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute bottom-0 p-6">
                    <h3 className="text-xl font-semibold text-white mb-2">{project.title}</h3>
                    <p className="text-gray-200 mb-4">{project.description}</p>
                    <button className="flex items-center text-white hover:text-red-300 transition-colors">
                      View Project <ChevronRight className="h-4 w-4 ml-1" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8">Let's Build Your Website</h2>
            <p className="text-gray-600 mb-8">
              Ready to take your online presence to the next level? Get in touch for a free consultation.
            </p>
            <form action="https://formspree.io/f/xldglokv" method="POST" className="space-y-4">
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                required
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                required
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
              <textarea
                name="message"
                placeholder="Your Message"
                required
                rows={4}
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-500 focus:border-transparent"
              ></textarea>
              <button type="submit" className="w-full bg-red-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-red-700 transition-colors">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Code2 className="h-8 w-8 text-red-500" />
                <span className="ml-2 text-xl font-bold">SimpleDotWeb</span>
              </div>
              <p className="text-gray-400">
                Simple Websites for Big Dreams – Built Just for You.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><a href="#about" className="text-gray-400 hover:text-red-500">About</a></li>
                <li><a href="#services" className="text-gray-400 hover:text-red-500">Services</a></li>
                <li><a href="#portfolio" className="text-gray-400 hover:text-red-500">Portfolio</a></li>
                <li><a href="#pricing" className="text-gray-400 hover:text-red-500">Pricing</a></li>
                <li><a href="#contact" className="text-gray-400 hover:text-red-500">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2">
                <li className="flex items-center text-gray-400">
                  <Mail className="h-4 w-4 mr-2" />
                  hello@simpledotweb.com
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-red-500">
                  <Github className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-red-500">
                  <Linkedin className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-red-500">
                  <Twitter className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>© 2024 SimpleDotWeb. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;